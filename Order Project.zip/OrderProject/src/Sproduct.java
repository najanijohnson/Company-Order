/**
* Represents a seasonal product (type S).
*/
class SProduct extends Product {
   private Date date;
   public SProduct(String name, double price, char type, Date date) {
       super(name, price, type);
       this.date = date; //seasonal products are based off of date
   }
   @Override
   public double total(int qty) {
       boolean isInSeason = date.getMonth() >= 10 && date.getMonth() <= 12; //pricing for seasonal products
       return isInSeason ? 0.6 * price * qty : price * qty;
   }
}
