/**
* Represents a regular product (type R).
*/
class RProduct extends Product { //subclass of product
   public RProduct(String name, double price, char type) {
       super(name, price, type);
   }
   @Override
   public double total(int qty) {
       return price * qty; //pricing for regular products
   }
}
