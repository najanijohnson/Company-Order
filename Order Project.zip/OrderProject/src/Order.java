/**
* Represents an order.
*/
public class Order {
   private Product product;
   private int quantity;
   private Date date;
   /**
    * Constructor to initialize an order.
    *
    * @param product  The product in the order.
    * @param quantity The quantity of the product in the order.
    * @param date     The date of the order.
    */
   public Order(Product product, int quantity, Date date) {
       this.product = product;
       this.quantity = quantity;
       this.date = date;
   }
   /**
    * Overrides the toString method to provide a string representation of the order.
    *
    * @return A string representation of the order.
    */
   @Override
   public String toString() {
       return "Order Details:\n" +
               "Product: " + product.toString() + "\n" +
               "Quantity: " + quantity + "\n" +
               "Order Date: " + date.toString();
   }
}
