/**
* Abstract class representing a product in the inventory.
*/
abstract class Product {
   private static int invSize = 0; // number of products in the inventory
   protected String name; //name of products
   protected double price; //price of products
   protected char type; // whether or not regular, seasonal, or bulk
   private int amount;  // Add an amount field to the Product class
   /**
    * Constructor to initialize a product.
    *
    * @param name  The name of the product.
    * @param price The regular price of the product.
    * @param type  The type of the product ('R', 'B', or 'S').
    */
   public Product(String name, double price, char type) {
       this.name = name;
       this.price = price;
       this.type = type;
       invSize++; // Increment the number of products in the inventory
   }
   /**
    * Sets the amount of the product.
    *
    * @param amount The quantity of the product.
    */
   public void setAmount(int amount) {
       //makes sure that the quantity is above 0 because you can't have negative products
       if (amount >= 0) {
           this.amount = amount;
       } else {
           System.out.println("Invalid amount. Amount can't be negative.");
       }
   }
   /**
    * Gets the amount of the product.
    *
    * @return The quantity of the product.
    */
   public int getAmount() {
       return amount;
   }
   /**
    * Gets the total price of the product based on the quantity.
    *
    * @param qty The quantity of the product.
    * @return The total price of the product.
    */
   public abstract double total(int qty);
   /**
    * Gets the size of the inventory.
    *
    * @return inventiry size.
    */
   public static int getInvSize() {
       return invSize;
   }
   /**
    * Overrides the toString method to provide a string representation of the product.
    *
    * @return A string representation of the product.
    */
   @Override
   public String toString() {
       return "Name: " + name + ", Regular Price: " + price + ", Type: " + type;
   }
   /**
    * Gets the name of the product.
    *
    * @return The name of the product.
    */
   public String getName() {
       return name;
   }
   /**
    * Gets the price of the product.
    *
    * @return The regular price of the product.
    */
   public double getPrice() {
       return price;
   }
}
