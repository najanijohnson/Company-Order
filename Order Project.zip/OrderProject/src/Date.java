/**
* Represents a date.
*/
public class Date {
   private int month;
   private int day;
   private int year;
   /**
    * Constructor to initialize a date from a string.
    *
    * @param dateString The date string in the format "mm/dd/yyyy".
    */
   public Date(String dateString) {
       String[] dateParts = dateString.split("/");
       if (dateParts.length == 3) {
           try {
               this.month = Integer.parseInt(dateParts[0]);
               this.day = Integer.parseInt(dateParts[1]);
               this.year = Integer.parseInt(dateParts[2]);
           } catch (NumberFormatException e) {
               System.out.println("Invalid date format. Please use mm/dd/yyyy.");
               // Handle the error or throw an exception as needed
           }
       } else {
           System.out.println("Invalid date format. Please use mm/dd/yyyy.");
           // Handle the error or throw an exception as needed
       }
   }
   /**
    * Gets the month of the date.
    *
    * @return The month of the date.
    */
   public int getMonth() {
       return month;
   }
   /**
    * Gets the day of the date.
    *
    * @return The day.
    */
   public int getDay() {
       return day;
   }
   /**
    * Gets the year of the date.
    *
    * @return The year.
    */
   public int getYear() {
       return year;
   }
   /**
    * Overrides the toString method to provide a string representation of the date.
    *
    * @return A string representation of the date.
    */
   @Override
   public String toString() {
       return month + "/" + day + "/" + year;
   }
}
