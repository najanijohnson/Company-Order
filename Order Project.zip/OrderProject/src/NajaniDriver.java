import java.io.*;
import java.util.ArrayList;
/**
* Driver class for the code I created
*/
public class NajaniDriver {
   public static void main(String[] args) {
       boolean quit = false;
       BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
       ArrayList<Product> inventory = null;
       ArrayList<Order> orderList = new ArrayList<>();
       while (!quit) {
           System.out.println("Menu:");
           System.out.println("1. Show the inventory.");
           System.out.println("2. Make an order.");
           System.out.println("3. Review orders.");
           System.out.println("4. Exit.");
           System.out.print("Enter your choice: ");
           try {
               int choice = Integer.parseInt(reader.readLine());
               switch (choice) {
                   case 1:
                       if (inventory == null) {
                           inventory = readInventoryData("data.txt"); //choosing option 1 shows you the inventory
                       }
                       showInventory(inventory);
                       break;
                   case 2:
                       if (inventory == null) {
                           inventory = readInventoryData("data.txt");
                       }
                       makeOrder(reader, inventory, orderList); //choosing option 2 allows you to make orders
                       break;
                   case 3:
                       showOrders(orderList); //choosing option 3 allows you to review all the orders you made
                       break;
                   case 4:
                       saveOrdersToFile(orderList); // allows you to quit program and saves to orders.txt file
                       quit = true;
                       System.out.println("Goodbye! Thanks for using my program.");
                       break;
                   default:
                       System.out.println("Invalid choice. Please choose a valid option.");
               }
           } catch (IOException | NumberFormatException e) {
               e.printStackTrace(); //I included this for my own debugging purposes its not that relevant to the code itself but I'll leave it
           }
       }
   }
   /**
    * Displays the inventory.
    *
    * @param inventory The list of products in the inventory.
    */
   private static void showInventory(ArrayList<Product> inventory) {
       for (Product item : inventory) {
           System.out.println(item.toString());
       }
   }
   /**
    * Takes user input to create a new order.
    *
    * @param reader     BufferedReader for reading user input.
    * @param inventory  ArrayList of products representing the inventory.
    * @param orderList  ArrayList of orders to store user orders.
    * @throws IOException If an I/O error occurs.
    */
   private static void makeOrder(BufferedReader reader, ArrayList<Product> inventory, ArrayList<Order> orderList)
           throws IOException {
       System.out.print("Enter the name of the product: ");
       String productName = reader.readLine();
       Product foundProduct = searchItem(inventory, productName);
       if (foundProduct != null) {
           //makes sure that the quantity chosen doesn't exceed the quantity in inventory
           int availableQuantity = foundProduct.getAmount();
           int quantity;
           do {
               System.out.print("Enter the quantity (max available: " + availableQuantity + "): "); //tells you max quantity and gives you quantity option
               quantity = Integer.parseInt(reader.readLine());
               if (quantity > availableQuantity) {
                   System.out.println("Sorry, that is above the amount we have in inventory. Please choose a lower quantity."); //if you pick above the set quantity it reprompts you to answer the question
               }
           } while (quantity > availableQuantity);
           boolean validDate = false;
           Date orderDate = null;
           // Keep asking for a valid date until the user provides one
           do {
               System.out.print("Enter the order date (mm/dd/yyyy): ");
               String dateString = reader.readLine();
               try {
                   orderDate = new Date(dateString);
                   validDate = true;
               } catch (IllegalArgumentException e) {
                   System.out.println("Invalid date format. Please use mm/dd/yyyy. Exiting out to Main Menu.");
               }
           } while (!validDate);
       }
   }
   /**
    * Displays the list of orders.
    *
    * @param orders The list of orders.
    */
   private static void showOrders(ArrayList<Order> orders) {
       System.out.println("List of Orders:");
       for (Order order : orders) {
           System.out.println(order.toString());
       }
   }
   /**
    * Saves the list of orders to a file.
    *
    * @param orders The list of orders.
    */
   private static void saveOrdersToFile(ArrayList<Order> orders) {
       try (FileWriter fileWriter = new FileWriter("orders.txt");
            BufferedWriter writer = new BufferedWriter(fileWriter)) {
           for (Order order : orders) {
               writer.write(order.toString());
               writer.newLine();
           }
       } catch (IOException e) {
           e.printStackTrace();
       }
   }
   /**
    * Searches for a product in the inventory by name.
    *
    * @param inventory   The list of products in the inventory.
    * @param searchName  The name of the product to search for.
    * @return            The found product or null if not found.
    */
   private static Product searchItem(ArrayList<Product> inventory, String searchName) {//Note: I modified this from my project 2 code
       String searchNameLower = searchName.toLowerCase();
       for (Product product : inventory) {
           String currentNameLower = product.getName().toLowerCase();
           if (currentNameLower.equals(searchNameLower)) {
               return product;  // Item found
           }
       }
       return null;  // Item not found
   }
   /**
    * Reads the inventory data from a file.
    *
    * @param filename The name of the file containing inventory data.
    * @return         The list of products in the inventory.
    * @throws IOException If an I/O error occurs.
    */
   public static ArrayList<Product> readInventoryData(String filename) throws IOException {
       ArrayList<Product> inventory = new ArrayList<>();
       try (BufferedReader input = new BufferedReader(new FileReader(filename))) {
           String line;
           while ((line = input.readLine()) != null) {
               String name = line.trim();
               double price = Double.parseDouble(input.readLine());
               int quantity = Integer.parseInt(input.readLine());
               char type = determineProductType(name);
               Product product;
               if (type == 'R') {
                   product = new RProduct(name, price, type);
               } else if (type == 'B') {
                   product = new BProduct(name, price, type);
               } else if (type == 'S') {
                   product = new SProduct(name, price, type, null);
               } else {
               	continue;
               }
               product.setAmount(quantity);
               inventory.add(product);
           }
       } catch (IOException e) {
           e.printStackTrace();
       }
       return inventory;
   }
    /**
    * Determines the product type based on the name.
    *
    * @param productName The name of the product.
    * @return            The product type.
    */
   private static char determineProductType(String productName) {
       char firstChar = productName.charAt(0);
       if (firstChar == 'B') {
           return 'B';
       } else if (firstChar == 'S') {
           return 'S';
       } else {
           return 'R';
       }
   }
}
