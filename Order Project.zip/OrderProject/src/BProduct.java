/**
* Represents a bulk product (type B).
*/
class BProduct extends Product {
   public BProduct(String name, double price, char type) {
       super(name, price, type);
   }
   @Override
   public double total(int qty) {
       if (qty < 100) {
           return price * qty;
       } else if (qty < 500) {
           return 0.95 * price * qty; // 5% discount
       } else if (qty < 1500) {
           return 0.85 * price * qty; // 15% discount
       } else {
           return 0.75 * price * qty; // 25% discount
       }
   }
}
